from django.apps import AppConfig


class UniAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'uni_app'
