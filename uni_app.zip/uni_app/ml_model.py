from sentence_transformers import SentenceTransformer
from uni_app.models import CourseEra2
import numpy as np

# Initialize the transformer model
model = SentenceTransformer('paraphrase-MiniLM-L6-v2')




